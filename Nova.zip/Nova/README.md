# Nova (N.O.V.A)

A Jarvis-style voice assistant for Android (built for a Pixel 9a).

- **Double clap** wakes her. She greets you with the weather, then listens.
- **Say "Nova"** and she reacts ("Yes?") and listens.
- **Speaks in your Fish Audio voice** (falls back to the phone's British voice if no Fish key is set).
- **Opens apps** by name ("open Maps").
- **Brain:** Claude, through the Anthropic API.

## Build and install

1. Install [Android Studio](https://developer.android.com/studio) on a computer.
2. File > Open > choose this `Nova` folder. Let Gradle sync (accept any AGP/Gradle upgrade prompt).
3. On the Pixel: Settings > About phone > tap Build number 7 times > Developer options > enable USB debugging.
4. Plug the phone in, pick it as the target, press Run.

## First-run setup in the app

1. Paste your **Anthropic API key** (console.anthropic.com). A Claude Code login can't be used by other apps.
2. Paste your **Fish Audio API key** and the **voice model ID** of the voice you want (copy it from that voice's page on fish.audio).
3. Tap **Test voice**.
4. Tap the three permission buttons. "Display over other apps" is what lets Nova open apps while the screen is off.
5. Optional: **Download name-detection model** so she answers to "Nova".
6. Tap **Start Nova**. Clap twice.

## Tuning

- Claps not detected: raise **Clap sensitivity**. False triggers: lower it.
- Model names are editable in the app (default brain is `claude-haiku-5-5` for speed; try `claude-sonnet-5-5` for smarter answers).

## Files

- `NovaService.kt` always-on listening loop and conversation flow
- `ClapDetector.kt` double-clap logic
- `VoskWake.kt` offline "Nova" name detection
- `Brain.kt` Claude API with `open_app` and `end_session` tools
- `Speaker.kt` Fish Audio voice with caching and British fallback
- `Weather.kt` Open-Meteo weather (no key needed)
- `AppLauncher.kt` finds and opens installed apps
- `MainActivity.kt` setup screen

Keys are stored only in the app's private storage on the phone.

Opening the project in Android Studio generates the Gradle wrapper for you (it will offer to use its bundled Gradle on first sync).
