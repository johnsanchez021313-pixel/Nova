package com.nova.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.zip.ZipInputStream

/** Downloads and locates the small offline English speech model used to hear the name "Nova". */
object ModelStore {
    const val NAME = "vosk-model-small-en-us-0.15"
    private const val URL = "https://alphacephei.com/vosk/models/$NAME.zip"

    fun dir(c: Context) = File(c.filesDir, NAME)
    fun ready(c: Context) = File(dir(c), "am/final.mdl").exists()

    suspend fun download(c: Context, onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(c.cacheDir, "model.zip")
        Net.http.newCall(Request.Builder().url(URL).build()).execute().use { r ->
            if (!r.isSuccessful) error("Download failed: HTTP ${r.code}")
            val body = r.body ?: error("Empty download")
            val total = body.contentLength()
            var done = 0L
            body.byteStream().use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            }
        }
        val root = c.filesDir.canonicalFile
        ZipInputStream(tmp.inputStream()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val target = File(root, e.name).canonicalFile
                if (!target.path.startsWith(root.path + File.separator)) continue // zip-slip guard
                if (e.isDirectory) target.mkdirs() else {
                    target.parentFile?.mkdirs()
                    target.outputStream().use { zin.copyTo(it) }
                }
            }
        }
        tmp.delete()
    }
}

/** Listens to the same 16 kHz audio stream as the clap detector and reports when it hears "nova". */
class VoskWake(modelDir: File) {
    private val model = Model(modelDir.absolutePath)
    // Restricted grammar: only "nova" or "unknown". Fast, tiny, and ignores everything else.
    private val rec = Recognizer(model, 16000f, "[\"nova\", \"[unk]\"]")

    fun feed(buf: ShortArray, len: Int): Boolean {
        val text = if (rec.acceptWaveForm(buf, len)) {
            JSONObject(rec.result).optString("text")
        } else {
            JSONObject(rec.partialResult).optString("partial")
        }
        if (text.split(" ").any { it == "nova" }) {
            rec.reset()
            return true
        }
        return false
    }

    fun reset() = rec.reset()

    fun close() {
        runCatching { rec.close() }
        runCatching { model.close() }
    }
}
