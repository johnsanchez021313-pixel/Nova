package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Finds an installed app by the name the user spoke and launches it. */
object AppLauncher {

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), "").trim()

    fun open(ctx: Context, spoken: String): String {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = norm(spoken)
        if (q.isEmpty()) return "No app name was given."

        val match = apps.firstOrNull { norm(it.first) == q }
            ?: apps.firstOrNull { norm(it.first).startsWith(q) }
            ?: apps.firstOrNull { norm(it.first).contains(q) }
            ?: apps.firstOrNull { norm(it.first).length >= 3 && q.contains(norm(it.first)) }
            ?: return "No installed app matches \"$spoken\"."

        // Android blocks background apps from starting activities unless this permission is granted.
        if (!Settings.canDrawOverlays(ctx)) {
            return "Found ${match.first} but could not open it: the user needs to allow 'Display over other apps' for Nova."
        }
        val launch = pm.getLaunchIntentForPackage(match.second)
            ?: return "Found ${match.first} but it has no launch screen."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(launch)
            "Opened ${match.first}."
        } catch (e: Exception) {
            "Could not open ${match.first}: ${e.message}"
        }
    }
}
