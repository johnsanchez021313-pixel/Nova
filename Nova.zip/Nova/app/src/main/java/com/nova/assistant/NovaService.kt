package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * The always-on part of Nova.
 *
 * Idle: one microphone stream feeds the double-clap detector and (optionally) the offline "Nova"
 * name detector. When either fires, the stream is released and a conversation starts:
 *   clap -> weather greeting -> listen / answer / listen ...
 *   name -> short spoken reaction -> listen / answer / listen ...
 * The conversation ends when Claude calls end_session or the user goes quiet; Nova then goes back to idle.
 */
class NovaService : Service() {
    private enum class Trigger { CLAP, NAME }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var mainJob: Job? = null
    private lateinit var speaker: Speaker
    private var recognizer: SpeechRecognizer? = null
    private var vosk: VoskWake? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        speaker = Speaker(this)
        val ch = NotificationChannel(CHANNEL, "Nova", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, notification("Listening for a double clap"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (mainJob == null) mainJob = scope.launch { mainLoop() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        recognizer?.destroy()
        vosk?.close()
        speaker.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- main loop

    private suspend fun mainLoop() {
        withContext(Dispatchers.IO) { speaker.warm(reactions()) }
        while (currentCoroutineContext().isActive) {
            val trigger = idleListen()
            if (trigger == null) {
                updateNotification("Microphone unavailable. Tap to open Nova.")
                stopSelf()
                return
            }
            updateNotification("Awake")
            try {
                runSession(trigger)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "session failed", e)
                updateNotification("Error: ${e.message}")
                runCatching { speaker.speak("I'm having trouble thinking just now, ${address()}.") }
            }
            updateNotification("Listening for a double clap")
        }
    }

    // ---------------------------------------------------------------- idle: claps + name

    @SuppressLint("MissingPermission")
    private suspend fun idleListen(): Trigger? = withContext(Dispatchers.IO) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return@withContext null

        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, rate)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return@withContext null
        }

        var found: Trigger? = null
        val clap = ClapDetector(Prefs.getInt(this@NovaService, Prefs.SENSITIVITY, 6)) { found = Trigger.CLAP }

        var v: VoskWake? = null
        if (Prefs.getBool(this@NovaService, Prefs.NAME_WAKE, true) && ModelStore.ready(this@NovaService)) {
            v = vosk ?: runCatching { VoskWake(ModelStore.dir(this@NovaService)) }
                .onFailure { Log.e(TAG, "Vosk failed to load", it) }
                .getOrNull()
            vosk = v
            v?.reset()
        }

        val buf = ShortArray(1600) // 100 ms
        rec.startRecording()
        try {
            while (isActive && found == null) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                val base = SystemClock.elapsedRealtime()
                var off = 0
                while (off < n && found == null) {
                    val len = minOf(320, n - off) // 20 ms frames
                    clap.feed(buf, off, len, base + off / 16)
                    off += len
                }
                if (found == null && v != null && v.feed(buf, n)) found = Trigger.NAME
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        found
    }

    // ---------------------------------------------------------------- conversation

    private suspend fun runSession(trigger: Trigger) {
        val addr = address()
        if (Prefs.get(this, Prefs.ANTHROPIC_KEY).isBlank()) {
            speaker.speak("I need an Anthropic API key before I can think, $addr. Open my app and paste one in.")
            return
        }
        val brain = Brain(this)

        when (trigger) {
            Trigger.CLAP -> {
                val weather = Weather.summary(this)
                val r = brain.say("[Wake-up] The user just clapped twice. Weather: $weather")
                speaker.speak(r.text)
                if (r.end) return
            }
            Trigger.NAME -> speaker.speak(reactions().random())
        }

        var misses = 0
        while (true) {
            val heard = listenOnce()
            if (heard.isNullOrBlank()) {
                if (++misses >= 2) break
                continue
            }
            misses = 0
            val r = brain.say(heard)
            if (r.text.isNotBlank()) speaker.speak(r.text)
            if (r.end) break
        }
    }

    private suspend fun listenOnce(): String? = suspendCancellableCoroutine { cont ->
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        val finish = { text: String? ->
            sr.destroy()
            if (recognizer === sr) recognizer = null
            if (cont.isActive) cont.resume(text)
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
            override fun onError(error: Int) { finish(null) }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
        cont.invokeOnCancellation { sr.destroy() }
        sr.startListening(intent)
    }

    // ---------------------------------------------------------------- helpers

    private fun address() = Prefs.get(this, Prefs.ADDRESS, "sir").ifBlank { "sir" }

    private fun reactions(): List<String> {
        val a = address()
        return listOf("Yes, $a?", "At your service, $a.", "I'm here.", "Listening.")
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, NovaService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Nova")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
    }

    companion object {
        const val ACTION_STOP = "com.nova.assistant.STOP"
        private const val CHANNEL = "nova"
        private const val NOTIF_ID = 7
        private const val TAG = "Nova"
    }
}
