package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Setup screen: keys, voice, sensitivity, permissions, start/stop. */
class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var speaker: Speaker? = null

    private lateinit var anthropicKey: EditText
    private lateinit var claudeModel: EditText
    private lateinit var fishKey: EditText
    private lateinit var fishVoice: EditText
    private lateinit var fishModel: EditText
    private lateinit var addressAs: EditText
    private lateinit var sensitivity: SeekBar
    private lateinit var nameSwitch: Switch
    private lateinit var modelStatus: TextView
    private lateinit var permStatus: TextView

    private val bg = Color.parseColor("#0B1118")
    private val fg = Color.parseColor("#E6F1F7")
    private val dim = Color.parseColor("#7F95A3")
    private val accent = Color.parseColor("#5CE1E6")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
            setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(0, b.top, 0, b.bottom)
                insets
            }
        }

        fun text(t: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0) =
            TextView(this).apply {
                this.text = t; textSize = size; setTextColor(color)
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, dp(top), 0, dp(4))
                col.addView(this)
            }

        fun field(hint: String, key: String, secret: Boolean = false, default: String = ""): EditText =
            EditText(this).apply {
                this.hint = hint
                setText(Prefs.get(this@MainActivity, key, default))
                setTextColor(fg); setHintTextColor(dim)
                isSingleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or
                    (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_NORMAL)
                col.addView(this)
            }

        fun button(label: String, onClick: () -> Unit) =
            Button(this).apply {
                text = label
                setOnClickListener { onClick() }
                col.addView(this)
            }

        text("N.O.V.A", 30f, accent, bold = true)
        text("Clap twice, or say \"Nova\".", 14f, dim)

        text("Brain (Anthropic API key)", 13f, accent, top = 20)
        anthropicKey = field("sk-ant-...", Prefs.ANTHROPIC_KEY, secret = true)
        claudeModel = field("Model", Prefs.CLAUDE_MODEL, default = "claude-haiku-5-5")

        text("Voice (Fish Audio)", 13f, accent, top = 20)
        fishKey = field("Fish Audio API key", Prefs.FISH_KEY, secret = true)
        fishVoice = field("Voice model ID (reference_id)", Prefs.FISH_VOICE)
        fishModel = field("Fish model", Prefs.FISH_MODEL, default = "s2.1-pro")
        button("Test voice") {
            save()
            val s = speaker ?: Speaker(this).also { speaker = it }
            scope.launch {
                runCatching { s.speak("Good evening, ${addressAs.text}. Nova online.") }
                    .onFailure { Toast.makeText(this@MainActivity, "Voice error: ${it.message}", Toast.LENGTH_LONG).show() }
            }
        }

        text("You", 13f, accent, top = 20)
        addressAs = field("How should Nova address you?", Prefs.ADDRESS, default = "sir")

        text("Waking up", 13f, accent, top = 20)
        text("Clap sensitivity", 12f, dim)
        sensitivity = SeekBar(this).apply {
            max = 9
            progress = Prefs.getInt(this@MainActivity, Prefs.SENSITIVITY, 6) - 1
            col.addView(this)
        }
        nameSwitch = Switch(this).apply {
            text = "Also wake when I say \"Nova\""
            setTextColor(fg)
            isChecked = Prefs.getBool(this@MainActivity, Prefs.NAME_WAKE, true)
            col.addView(this)
        }
        modelStatus = text("", 12f, dim)
        button("Download name-detection model (about 40 MB)") { downloadModel() }

        text("Permissions", 13f, accent, top = 20)
        permStatus = text("", 12f, dim)
        button("1. Allow microphone, location, notifications") { askRuntimePermissions() }
        button("2. Allow \"Display over other apps\" (to open apps)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Don't restrict battery (keeps Nova listening)") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }

        text("", 12f, dim, top = 12)
        button("Start Nova") { start() }
        button("Stop Nova") { stopService(Intent(this, NovaService::class.java)); toast("Nova stopped.") }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        Weather.cacheLocation(this)
        refreshStatus()
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        speaker?.shutdown()
        super.onDestroy()
    }

    private fun save() {
        Prefs.put(this, Prefs.ANTHROPIC_KEY, anthropicKey.text.toString().trim())
        Prefs.put(this, Prefs.CLAUDE_MODEL, claudeModel.text.toString().trim())
        Prefs.put(this, Prefs.FISH_KEY, fishKey.text.toString().trim())
        Prefs.put(this, Prefs.FISH_VOICE, fishVoice.text.toString().trim())
        Prefs.put(this, Prefs.FISH_MODEL, fishModel.text.toString().trim())
        Prefs.put(this, Prefs.ADDRESS, addressAs.text.toString().trim())
        Prefs.putInt(this, Prefs.SENSITIVITY, sensitivity.progress + 1)
        Prefs.putBool(this, Prefs.NAME_WAKE, nameSwitch.isChecked)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refreshStatus() {
        modelStatus.text = if (ModelStore.ready(this)) "Name-detection model: installed" else "Name-detection model: not installed (claps still work)"
        fun mark(ok: Boolean) = if (ok) "yes" else "NO"
        permStatus.text = "Microphone: ${mark(has(Manifest.permission.RECORD_AUDIO))}   " +
            "Location: ${mark(has(Manifest.permission.ACCESS_COARSE_LOCATION))}   " +
            "Over other apps: ${mark(Settings.canDrawOverlays(this))}"
    }

    private fun askRuntimePermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Weather.cacheLocation(this)
        refreshStatus()
    }

    private fun downloadModel() {
        scope.launch {
            try {
                ModelStore.download(this@MainActivity) { pct -> modelStatus.post { modelStatus.text = "Downloading model... $pct%" } }
                refreshStatus()
                toast("Model installed. Restart Nova to use it.")
            } catch (e: Exception) {
                modelStatus.text = "Download failed: ${e.message}"
            }
        }
    }

    private fun start() {
        save()
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            toast("Allow the microphone first (button 1).")
            askRuntimePermissions()
            return
        }
        if (Prefs.get(this, Prefs.ANTHROPIC_KEY).isBlank()) {
            toast("Paste your Anthropic API key first.")
            return
        }
        stopService(Intent(this, NovaService::class.java))
        startForegroundService(Intent(this, NovaService::class.java))
        toast("Nova is listening. Clap twice.")
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
