package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.CancellationSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import kotlin.coroutines.resume

/** Current weather from Open-Meteo (free, no key). Location is coarse and cached on the phone. */
object Weather {

    private fun hasLocationPermission(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Call whenever the app is in the foreground; background services often can't get a fresh fix. */
    fun cacheLocation(c: Context) {
        if (!hasLocationPermission(c)) return
        val lm = c.getSystemService(LocationManager::class.java)
        val best = lm.getProviders(true)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time } ?: return
        Prefs.put(c, Prefs.LAST_LAT, best.latitude.toString())
        Prefs.put(c, Prefs.LAST_LON, best.longitude.toString())
    }

    private suspend fun freshFix(c: Context): Location? = withTimeoutOrNull(4000) {
        if (!hasLocationPermission(c)) return@withTimeoutOrNull null
        suspendCancellableCoroutine<Location?> { cont ->
            val signal = CancellationSignal()
            cont.invokeOnCancellation { signal.cancel() }
            try {
                c.getSystemService(LocationManager::class.java)
                    .getCurrentLocation(LocationManager.NETWORK_PROVIDER, signal, c.mainExecutor) { loc ->
                        if (cont.isActive) cont.resume(loc)
                    }
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }

    /** A compact plain-text weather summary for Claude to turn into a spoken sentence. */
    suspend fun summary(c: Context): String = withContext(Dispatchers.IO) {
        val fix = freshFix(c)
        val lat: Double
        val lon: Double
        if (fix != null) {
            lat = fix.latitude; lon = fix.longitude
            Prefs.put(c, Prefs.LAST_LAT, lat.toString()); Prefs.put(c, Prefs.LAST_LON, lon.toString())
        } else {
            val la = Prefs.get(c, Prefs.LAST_LAT).toDoubleOrNull()
            val lo = Prefs.get(c, Prefs.LAST_LON).toDoubleOrNull()
            if (la == null || lo == null) return@withContext "Weather unavailable: no location yet (the user should open the Nova app once with location allowed)."
            lat = la; lon = lo
        }
        val us = Locale.getDefault().country == "US"
        val tUnit = if (us) "fahrenheit" else "celsius"
        val sym = if (us) "°F" else "°C"
        val wUnit = if (us) "mph" else "kmh"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&temperature_unit=$tUnit&wind_speed_unit=$wUnit&timezone=auto&forecast_days=1"
        try {
            Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return@withContext "Weather unavailable (service error ${r.code})."
                val j = JSONObject(r.body!!.string())
                val cur = j.getJSONObject("current")
                val day = j.getJSONObject("daily")
                "Right now ${cur.getDouble("temperature_2m").toInt()}$sym " +
                    "(feels like ${cur.getDouble("apparent_temperature").toInt()}$sym), " +
                    "${describe(cur.getInt("weather_code"))}, wind ${cur.getDouble("wind_speed_10m").toInt()} $wUnit. " +
                    "Today's high ${day.getJSONArray("temperature_2m_max").getDouble(0).toInt()}$sym, " +
                    "low ${day.getJSONArray("temperature_2m_min").getDouble(0).toInt()}$sym, " +
                    "chance of precipitation ${day.getJSONArray("precipitation_probability_max").optInt(0)}%."
            }
        } catch (e: Exception) {
            "Weather unavailable (${e.message})."
        }
    }

    private fun describe(code: Int) = when (code) {
        0 -> "clear sky"
        1 -> "mostly clear"
        2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "foggy"
        in 51..57 -> "drizzle"
        in 61..67 -> "rain"
        in 71..77 -> "snow"
        in 80..82 -> "rain showers"
        85, 86 -> "snow showers"
        in 95..99 -> "thunderstorms"
        else -> "mixed conditions"
    }
}
