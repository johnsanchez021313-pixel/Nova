package com.nova.assistant

import android.content.Context
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Tiny SharedPreferences wrapper. Everything is stored privately on the phone. */
object Prefs {
    const val ANTHROPIC_KEY = "anthropic_key"
    const val CLAUDE_MODEL = "claude_model"
    const val FISH_KEY = "fish_key"
    const val FISH_VOICE = "fish_voice"
    const val FISH_MODEL = "fish_model"
    const val ADDRESS = "address_as"
    const val SENSITIVITY = "clap_sensitivity"
    const val NAME_WAKE = "name_wake"
    const val LAST_LAT = "last_lat"
    const val LAST_LON = "last_lon"

    private fun sp(c: Context) = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getInt(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
}

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()
}
