package com.nova.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Nova's voice.
 *
 * With a Fish Audio key (and voice ID) she speaks in that voice: the reply is split into sentences,
 * all of them are synthesised in parallel, and played back in order so the first sentence starts
 * quickly. Short lines (reactions, greetings) are cached on disk so they play instantly next time.
 * Without a key she falls back to the phone's built-in British voice.
 */
class Speaker(private val ctx: Context) {
    private class Clip(val file: File, val temp: Boolean)

    private val dir = File(ctx.filesDir, "voice").apply { mkdirs() }
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    suspend fun speak(text: String) = coroutineScope {
        val parts = split(clean(text))
        if (parts.isEmpty()) return@coroutineScope
        val key = Prefs.get(ctx, Prefs.FISH_KEY)
        if (key.isBlank()) {
            parts.forEach { speakFallback(it) }
            return@coroutineScope
        }
        val jobs = parts.map { p -> async(Dispatchers.IO) { runCatching { fetch(p, key) }.getOrNull() } }
        parts.forEachIndexed { i, p ->
            val clip = jobs[i].await()
            if (clip == null) {
                speakFallback(p)
            } else {
                try {
                    play(clip.file)
                } finally {
                    if (clip.temp) clip.file.delete()
                }
            }
        }
    }

    /** Pre-generate short lines so they are instant later. Safe to call without a key. */
    fun warm(lines: List<String>) {
        val key = Prefs.get(ctx, Prefs.FISH_KEY)
        if (key.isBlank()) return
        lines.forEach { runCatching { fetch(it, key) } }
    }

    private fun fetch(text: String, key: String): Clip {
        val voice = Prefs.get(ctx, Prefs.FISH_VOICE).trim()
        val model = Prefs.get(ctx, Prefs.FISH_MODEL, "s2.1-pro").ifBlank { "s2.1-pro" }
        val cacheable = text.length <= 60
        val cached = File(dir, sha1("$model|$voice|$text") + ".mp3")
        if (cacheable && cached.exists()) return Clip(cached, false)

        val json = JSONObject()
            .put("text", text)
            .put("format", "mp3")
            .put("mp3_bitrate", 128)
            .put("latency", "balanced")
        if (voice.isNotEmpty()) json.put("reference_id", voice)

        val req = Request.Builder()
            .url("https://api.fish.audio/v1/tts")
            .header("Authorization", "Bearer $key")
            .header("model", model)
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        Net.http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Fish Audio ${r.code}: ${r.body?.string()?.take(200)}")
            val bytes = r.body!!.bytes()
            val out = if (cacheable) cached else File(ctx.cacheDir, "tmp-${System.nanoTime()}.mp3")
            out.writeBytes(bytes)
            return Clip(out, !cacheable)
        }
    }

    private suspend fun play(file: File) = suspendCancellableCoroutine<Unit> { cont ->
        val mp = MediaPlayer()
        cont.invokeOnCancellation { runCatching { mp.release() } }
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { it.release(); if (cont.isActive) cont.resume(Unit) }
            mp.setOnErrorListener { m, _, _ -> m.release(); if (cont.isActive) cont.resume(Unit); true }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            runCatching { mp.release() }
            if (cont.isActive) cont.resume(Unit)
        }
    }

    private suspend fun speakFallback(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        fun go(t: TextToSpeech) {
            val id = UUID.randomUUID().toString()
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
            })
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        }

        val existing = tts
        if (existing != null && ttsReady) {
            go(existing)
        } else {
            var created: TextToSpeech? = null
            created = TextToSpeech(ctx) { status ->
                val t = created
                if (status == TextToSpeech.SUCCESS && t != null) {
                    t.language = Locale.UK
                    t.setSpeechRate(0.92f)
                    ttsReady = true
                    go(t)
                } else if (cont.isActive) {
                    cont.resume(Unit)
                }
            }
            tts = created
        }
        cont.invokeOnCancellation { tts?.stop() }
    }

    fun shutdown() {
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        ttsReady = false
    }

    private fun clean(s: String) =
        s.replace(Regex("[*_#`~>|]"), "").replace(Regex("\\s+"), " ").trim()

    /** Sentence split; tiny fragments are merged forward so we don't make a request for "Hm." */
    private fun split(s: String): List<String> {
        if (s.isBlank()) return emptyList()
        val out = mutableListOf<String>()
        var carry = ""
        for (piece in s.split(Regex("(?<=[.!?])\\s+"))) {
            carry = if (carry.isEmpty()) piece else "$carry $piece"
            if (carry.length >= 25) { out += carry; carry = "" }
        }
        if (carry.isNotEmpty()) {
            if (out.isEmpty()) out += carry else out[out.lastIndex] = out.last() + " " + carry
        }
        return out.take(8)
    }

    private fun sha1(s: String) =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
