package com.nova.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Nova's brain: one conversation with Claude via the Anthropic Messages API.
 * Claude can call two tools: open_app and end_session.
 */
class Brain(private val ctx: Context) {
    class Reply(val text: String, val end: Boolean)

    private val history = JSONArray()
    private var ended = false

    suspend fun say(userText: String): Reply = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("content", userText))
        val spoken = StringBuilder()

        repeat(5) {
            val resp = call()
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))

            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> spoken.append(b.getString("text")).append(' ')
                    "tool_use" -> {
                        val out = runTool(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                        results.put(
                            JSONObject().put("type", "tool_result")
                                .put("tool_use_id", b.getString("id"))
                                .put("content", out)
                        )
                    }
                }
            }
            if (results.length() == 0) return@withContext Reply(spoken.toString().trim(), ended)
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        Reply(spoken.toString().trim(), ended)
    }

    private fun runTool(name: String, input: JSONObject): String = when (name) {
        "open_app" -> AppLauncher.open(ctx, input.optString("app_name"))
        "end_session" -> { ended = true; "Session ended." }
        else -> "Unknown tool."
    }

    private fun call(): JSONObject {
        val key = Prefs.get(ctx, Prefs.ANTHROPIC_KEY).trim()
        val model = Prefs.get(ctx, Prefs.CLAUDE_MODEL, "claude-haiku-5-5").ifBlank { "claude-haiku-5-5" }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 500)
            .put("system", system())
            .put("tools", tools())
            .put("messages", history)
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", key)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        Net.http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Claude API ${r.code}: ${s.take(200)}")
            return JSONObject(s)
        }
    }

    private fun system(): String {
        val addr = Prefs.get(ctx, Prefs.ADDRESS, "sir").ifBlank { "sir" }
        val now = SimpleDateFormat("EEEE, MMMM d, h:mm a", Locale.getDefault()).format(Date())
        return """
            You are Nova (N.O.V.A), the user's personal voice assistant on their phone, in the spirit of Jarvis from Iron Man.
            You are calm, composed, quietly confident and dryly witty, never gushing or over-eager.
            Everything you write is read aloud by a speech engine, so write the way you would speak: plain sentences, no markdown, no lists, no emoji, no URLs, no stage directions. Usually one to three sentences.
            Address the user as "$addr" now and then, not in every sentence.
            Use the open_app tool when asked to open or launch an app, and confirm in a few words.
            When the user is finished (thanks, that's all, goodbye, stand down), give a brief sign-off and call end_session.
            For now you can only converse and open apps. If asked for something beyond that, say so plainly instead of pretending.
            When a message starts with [Wake-up], the user has just woken you with a double clap: greet them for the time of day and give the weather in a sentence or two, naturally, without reading numbers like a report.
            Current local date and time: $now.
        """.trimIndent()
    }

    private fun tools() = JSONArray()
        .put(
            JSONObject()
                .put("name", "open_app")
                .put("description", "Open an app installed on the user's phone by name.")
                .put(
                    "input_schema", JSONObject()
                        .put("type", "object")
                        .put(
                            "properties", JSONObject().put(
                                "app_name", JSONObject()
                                    .put("type", "string")
                                    .put("description", "The app's name as the user would say it, e.g. Maps, Spotify, Camera")
                            )
                        )
                        .put("required", JSONArray().put("app_name"))
                )
        )
        .put(
            JSONObject()
                .put("name", "end_session")
                .put("description", "End the conversation so Nova goes back to sleep and waits for the next wake-up.")
                .put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
        )
}
