package com.nova.assistant

import kotlin.math.max
import kotlin.math.sqrt

/**
 * Detects two sharp claps in quick succession.
 *
 * Feed it 20 ms frames of 16 kHz mono PCM. A clap is a short burst (<= 160 ms) that is much louder
 * than the room's running noise level. Two of them 120-900 ms apart fire [onDoubleClap].
 *
 * sensitivity 1..10: higher = triggers on quieter claps (but may false-trigger more).
 */
class ClapDetector(
    private val sensitivity: Int,
    private val onDoubleClap: () -> Unit,
) {
    private var noise = 400.0
    private var inClap = false
    private var clapStartMs = 0L
    private var firstClapMs = 0L

    fun feed(buf: ShortArray, off: Int, len: Int, nowMs: Long) {
        var sum = 0.0
        for (i in off until off + len) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        val rms = sqrt(sum / len)

        val factor = 12.0 - sensitivity            // 6 -> 6x the room noise
        val floor = 3000.0 - sensitivity * 200.0   // 6 -> never below 1800 rms
        val trigger = max(noise * factor, floor)

        if (!inClap) {
            if (rms > trigger) {
                inClap = true
                clapStartMs = nowMs
            } else {
                noise = max(50.0, noise * 0.995 + rms * 0.005)
            }
        } else if (rms < trigger * 0.4) {
            inClap = false
            if (nowMs - clapStartMs <= 160) registerClap(nowMs)
            // longer bursts are speech / music / a door slam: ignore
        }
    }

    private fun registerClap(nowMs: Long) {
        val gap = nowMs - firstClapMs
        if (firstClapMs != 0L && gap in 120L..900L) {
            firstClapMs = 0L
            onDoubleClap()
        } else {
            firstClapMs = nowMs
        }
    }
}
